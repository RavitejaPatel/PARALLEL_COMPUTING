
#include <iostream>
#include "ThreadGroup.h"
using namespace std;

const int dataLength = 1000 * 1000 / 2;

int encode(int v) {

	for (int i = 0; i < 500; i++)
		v = ((v * v) + v) % 10;
	return v;
}

int decode(int v) {
	// do something time-consuming (and arbitrary)
	return encode(v);
}


class DecodeThread
{
public:

	void operator()(int id, void* sharedData) {
		int* data = (int*)sharedData;

		for (int i = 0; i < dataLength; i++)
			data[i] = decode(data[i]);
	}
};



class EncodeThread
{
public:
	
	void operator()(int id, void* sharedData) {
		int* data = (int*)sharedData;

		int encodedSum = 0;
		for (int i = 0; i < dataLength; i++) {
			encodedSum += encode(data[i]);
			data[i] = encodedSum;
		}
	}
};






void prefixSums(int *data, int length)
 {
	


	ThreadGroup<EncodeThread> encoders;

	
	encoders.createThread(0, data);
	encoders.createThread(1, data+dataLength);
	encoders.waitForAll();

	
	int fhalfEncodePrefixSum = data[dataLength - 1];

	for (int i = dataLength; i < length; i++)
		data[i] += fhalfEncodePrefixSum;

	 
	decodes.createThread(0, data);
	decodes.createThread(1, data + dataLength);
	decodes.waitForAll();
}



int main() {
	
	int length = 1000 * 1000;

	int *data = new int[length];
	for (int i = 1; i < length; i++)
		data[i] = 1;
	data[0] = 6;

	
	prefixSums(data, length);


	cout << "[0]: " << data[0] << endl
			<< "[" << length/2 << "]: " << data[length/2] << endl 
			<< "[end]: " << data[length-1] << endl; 

    delete[] data;
	return 0;
}
