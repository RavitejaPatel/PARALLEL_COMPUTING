package prt;


import java.lang.Object;
import java.util.Collections;
import java.util.Random;
import java.util.concurrent.BrokenBarrierException;
import java.util.concurrent.CyclicBarrier;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;
import java.io.Serializable;
import java.util.Scanner;
//import assign3.BitonicStage;
//import assign3.RandomArrayGenerator;
//import assign3.StageOne;

/*
* 
* A thread-runnable Bitonic loop for sorting array using Bitonic Sort
* Given number of threads P, Granularity value and N as order for the power of 2
* 
*/
public class BitonicLoop implements Runnable {
	final static int TIME_ALLOWED = 10;
	static int ORDER = 22; 
	static int N = 1 << ORDER; // power of 2
	public static CyclicBarrier barrier; 


	private int GRANULARITY;
	private double data[] = new double[N];
	private int P;
	
	
	//initializing using constructors
	public BitonicLoop(double[] data, int P, int GRANULARITY) {
		this.data = data;
		this.P = P;
		this.GRANULARITY = GRANULARITY;
		barrier = new CyclicBarrier(P+1);
	}


	 //flow of bitonic  
	public static String fourbits(int n) {
		String ret = /* to_string(n) + */(n > 15 ? "/1" : "/");
		for (int bit = 3; bit >= 0; bit--)
			ret += (n & (1 << bit)) > 0 ? "1" : "0";
		return ret;
	}//fourbits

	static void randomArray(double v[], int lo, int hi) {
		Random rand = new Random(hi - lo);
		for (int i = v.length - 1; i >= 0; i--)
			v[i] = (double)lo + rand.nextDouble()*100;
	}//randomarray


	public static void main(String[] args) {
		
		
		final int P = 16;
		int work = 0;
		double[] inputData = new double[N];
		final int GRANULARITY = 1;
		long start = System.currentTimeMillis();
		
	

		while (System.currentTimeMillis() < start + TIME_ALLOWED * 1000) {
			randomArray(inputData, 0, N);
			BitonicLoop bitonicLoopObj = new BitonicLoop(inputData, P, GRANULARITY);
			 
			// we create a thread and wait on this thread for the barrier for Higher Granularity 1
	        Thread t1 = new Thread(bitonicLoopObj); 
	        t1.start(); 
	        try {
				t1.join();
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

			if (!isSorted(inputData)) {
				System.out.println("failed");
			}
			work++;
		}

		System.out.println("T = " + TIME_ALLOWED + " seconds");
		System.out.println(work + "  double sorted arrys");
		System.out.println("N = " + N);
		System.out.println("P = " + P);
		System.out.println("Granuality = " + GRANULARITY + "levels");
		
	}

	private static boolean isSorted(double[] inputData) {
		double prev = inputData[0];
		for (int i = 1; i < inputData.length; i++) {
			if (prev > inputData[i]) {
				return false;
			}
			prev = inputData[i];
		}
		return true;
	}

	@Override
	public void run() {

		int n = data.length;
		
		
		//reusing bitoniloop code for soryting array 
		for (int k = 2; k <= n; k *= 2) { 

			
			for (int j = k / 2; j > 0; j /= 2) { 
				
			
				int sizeofdivArr = n/P;

				int numOfBarriers = Math.floorMod(0 /*start i index*/, j);
				numOfBarriers = numOfBarriers > GRANULARITY-1 ? GRANULARITY-1 : numOfBarriers;
				CyclicBarrier[] granularBarrier = new CyclicBarrier[numOfBarriers];
				
				for(int pIndex = 0; pIndex < numOfBarriers; pIndex++) {
					granularBarrier[pIndex] = new CyclicBarrier(P);
				}
				for(int index = 0; index < P; index++)
				{
					int iStart = index * sizeofdivArr;
					int iEnd = iStart + sizeofdivArr;
					
				
					Thread t = new Thread(new Gsorting(data, iStart, iEnd, j, k, granularBarrier, barrier));
					t.start();
				}
		  
				
				
				//exception handling
	            try {
					barrier.await(TIME_ALLOWED*1000, TimeUnit.MILLISECONDS);
					barrier.reset();
				} catch (InterruptedException e) {
					e.printStackTrace();
				}  catch (TimeoutException e) {
					e.printStackTrace();
				}
	            catch (BrokenBarrierException e) {
					e.printStackTrace();
				}
			}
		}
	}
}//class
