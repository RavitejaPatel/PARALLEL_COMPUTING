package hw3_setup;
    
import java.util.ArrayList;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.SynchronousQueue;
import java.util.concurrent.TimeUnit;


public class BitonicPipeline
 {​​​​​​​


    public static final int N = 1 << 22;  // size of the final sorted array (power of two)
    public static final int TIME_ALLOWED = 100;  // seconds


    
    BitonicPipeline(int size, SynchronousQueue<double[]> input1, SynchronousQueue<double[]> input2, SynchronousQueue<double[]> output) 
    {​​​​​​​
        System.out.println("constructor initializatiuon");
    }​​​​​​​
   
    public static void main(String[] args) 
    
    {​​​​​​​
        long start = System.currentTimeMillis();
        int work = 0;
       while (System.currentTimeMillis() < start + TIME_ALLOWED * 1000) 
        {​​​​​​​
           double[][] dataOutput;// = new double[4][];
            double[][] data = new double[4][];
            int totalSections = data.length;
            int section = 0;
            ArrayList<SynchronousQueue<double[]>> outputSortedArray = new ArrayList<>();
            SynchronousQueue<double[]> stageOneOutputArray = new SynchronousQueue<>();
            ExecutorService executors = Executors.newFixedThreadPool(4);
            //for (int section = 0; section < totalSections; section++) {​​​​​​​
            try {​​​​​​​
                SynchronousQueue<double[]> outputRandomArray = new SynchronousQueue<>();
                RandomArrayGenerator randomArray = new RandomArrayGenerator(N/4, outputRandomArray);
                Thread t1 = new Thread(randomArray); 
                StageOne stageOneObj = new StageOne(outputRandomArray, stageOneOutputArray);//.get(section));  // Just sorts it\
                Thread t2 = new Thread(stageOneObj);


                    System.out.println("inside the pipeline: added something");//stageOneOutputArray.peek().length);
                    

                        System.out.println("Size of the output sorted array in the end: "+outputSortedArray.size() );
                      


                        for(int i = 0; i < 4; i++)
                        {​​​​​​​
                        //    
                            t1.start();
                            t2.start();

                        }​​​​​

                
            }​​​
            catch(Exception ex)
            {​​​​​​​
                ex.printStackTrace();
                System.out.println("threw an error : "+ ex);
            }​​​​​​​
            

            SynchronousQueue<double[]> penult1 = new SynchronousQueue<double[]>();
            SynchronousQueue<double[]> penult2 = new SynchronousQueue<double[]>();
            SynchronousQueue<double[]> finalval = new SynchronousQueue<double[]>();
            BitonicStage bitonic1 = new BitonicStage(stageOneOutputArray, penult1);
            Thread t3 = new Thread(bitonic1);
            t3.start();
            //executors.execute(t3);
//            t3.start();
            BitonicStage bitonic2 = new BitonicStage(stageOneOutputArray, penult2);
            Thread t4 = new Thread(bitonic2);
            executors.execute(t4);
//            t4.start();
            BitonicStage bitonic3 = new BitonicStage(stageOneOutputArray, finalval);
            Thread t5 = new Thread(bitonic3);
            executors.execute(t5);

            double[] ult;
            try {​​​​​​​
                ult = finalval.poll(TIME_ALLOWED, TimeUnit.MILLISECONDS);
                if (!RandomArrayGenerator.isSorted(ult) || N != ult.length)
                    System.out.println("failed");
            }​​​​​​​ //try
            
            
            catch (InterruptedException e)
             {​​​​​​​
                // TODO Auto-generated catch block
                e.printStackTrace();
            }​​​​​​​
            work++;
        }​​​​​​​
        System.out.println("sorted " + work + " arrays (each: " + N + " doubles) in "
                + TIME_ALLOWED + " seconds");



    }//while

    }​​​​​​​//main


}​​​​​​​//class
 









