package com.rt;

import java.util.ArrayList;
import java.util.Collections;

public class SumHeap extends Gscan 
{
	
	private static final long serialVersionUID = 1L;
	public int index;
	public SumHeap(ArrayList<Integer> data, int index) 
	{
		super(data, 0);
		this.index = index;
		interior = new ArrayList<Integer>(Collections.nCopies(n, 0));
	}

	protected Integer init() 
	{
		return 0;
	}
	
	protected  Integer prepare(Integer datum) 
	{
		return datum;
	}
	
	@Override
	protected Integer combine(Integer left, Integer right) 
	{
		System.out.println("left: "+left+" right: "+right);
		return left + right;
	}

}
