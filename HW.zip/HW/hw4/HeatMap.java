package com.separateHMtest;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.io.Serializable;

/**
 * Tally of Observations using a timestamp.
 * HW6
 */
public class HeatMap implements Serializable, Cloneable{
	private static final long serialVersionUID = -74910217358788424L;
    public HashMap<Long, int[]> heatmap;
    private double low, high;
    private int dim = 20; // dimension of heat map
    private double[] cells;
    
    /**
     * Constructor initialization 
     */
    public HeatMap(int dim, double low, double high) {
		this.dim = dim;
		this.low = low;
		this.high = high;
		cells = new double[dim * dim];
	}
    public HeatMap() {
        heatmap = new HashMap<>();
    }

    //single param constructor
    public HeatMap(Observation o) {
        this();
        accum(o);
    }

   
    private int place(double place) {
        return (int) ((place  + 1.0) / (2.0 / dim));
    }

    /**
     * Increments the value for a cell in array
     **/
    private void incrementCell(Long time, int r, int c) {
        int [] map = this.heatmap.get(time);
        map[r * dim + c]++;
    }
    
    
	public double getCell(int r, int c) {
		return cells[r * dim + c];
	}
	
	public void setCell(int r, int c, double value) {
		cells[r * dim + c] = value;
	}

   
    public static HeatMap combine(HeatMap a, HeatMap b) {
        HeatMap combinedTally = new HeatMap();
        //coping data from A
        for (HashMap.Entry<Long, int[]> entry: a.heatmap.entrySet()) {
            Long time = entry.getKey();
            int[] aHeatMap = entry.getValue();
            System.out.println(aHeatMap);
            combinedTally.heatmap.put(time, aHeatMap);
        }

        // copy data from B over
        for (HashMap.Entry<Long, int[]> entry: b.heatmap.entrySet()) {
            Long bTime = entry.getKey();
            int[] bHeatMap = entry.getValue();
            int [] cHeatMap = combinedTally.heatmap.get(bTime);
            if (cHeatMap == null) {
                combinedTally.heatmap.put(bTime, bHeatMap);
            }
            else {
                for (int i = 0; i < cHeatMap.length; i++) {
                    cHeatMap[i] += bHeatMap[i];
                }
            }
        }
        return combinedTally;
    }


    public void accum(Observation o) {
        Long time = o.time;
        int [] map = this.heatmap.get(time);
        if (map == null) {
            map = new int[dim * dim]; //create a new int array
            this.heatmap.put(time, map);
        }
        incrementCell(time, place(o.x), place(o.y));
    }

    /**
     * String representation of the hash
     */
    public String toString() {
        String s = "";
        for (HashMap.Entry<Long, int[]> entry: this.heatmap.entrySet
                ()) {
            Long t = entry.getKey();
            int[] hmap = entry.getValue();
            String timeStamp = t + ": " + Arrays.toString(hmap);
            s += timeStamp;
            s += "\n";
        }
        return s;
    }
}

class HeatMapScan2 extends GeneralScan3<Observation, HeatMap> {

    public HeatMapScan2(List<Observation> raw, int threshold) {
        super(raw, threshold);
    }

    @Override
    protected HeatMap init() {
        return new HeatMap();
    }

    @Override
    protected HeatMap prepare(Observation o) {
        return new HeatMap(o);
    }

    @Override
    protected HeatMap combine(HeatMap a, HeatMap b) {
        return HeatMap.combine(a, b);
    }
    @Override
    protected void accum(HeatMap tally, Observation o) {
        tally.accum(o);
    }
}
