#USECASE

This application is based on spark with java. The main goal of this application is to perform HW1 task which computes 1000000 array elements to encode and decode methods using sequential and parallel approach by implementing Runnable interface
In this task I have created Spark context and passed the dataset to parallize and assigned to RDD
RDD future creates into multiple partitions and performs the task
So from this I can compare the executing time of sequential using spark and parallizing using multithreading

#ENVIRONMENT
JRE 1.8
spark-core_2.10
windows10 OS



