package com.rt;

	import java.io.FileInputStream;
	import java.io.FileOutputStream;
	import java.io.IOException;
	import java.io.ObjectInputStream;
	import java.io.ObjectOutputStream;
	import java.util.ArrayList;
	import java.util.Collections;
	import java.util.HashMap;
	import java.util.LinkedList;
	import java.util.concurrent.ForkJoinPool;

	public class Gmems {
	
		public boolean testStream() 
		{
		
	       
	        
	        //providing abosolute path please specify filename dirextly
	        final int N = 1<<22; 
	        final String FILENAME = "D:\\PARALLEL COMPUTING ASSIGNMENTS\\Assin_5\\HEATMAPS\\observation_test.dat";
	   	 final double iterate = (double)2/(double)N;
	       
	        
	        try {
	            ObjectOutputStream out = new ObjectOutputStream(new FileOutputStream(FILENAME));
	            for (long t = 0; t < 6; t++)
	                for (double x = -1; x < 1.0; x += iterate)
	                    for (double y = 1; y > -1; y -= iterate)
	                        out.writeObject(new Observation(t, x, y));
	            out.writeObject(new Observation()); 
	            out.close();
	        } catch (IOException e) {
	            System.out.println("writing to " + FILENAME + "failed: " + e);
	            e.printStackTrace();
	            System.exit(1);
	        }

			
	        HashMap<Integer, LinkedList<Double>> observationByTimePerX = new HashMap<Integer, LinkedList<Double>>();
	        HashMap<Integer, LinkedList<Double>> observationByTimePerY = new HashMap<Integer, LinkedList<Double>>();
	        
	        try {
	            ObjectInputStream in = new ObjectInputStream(new FileInputStream(FILENAME));
	            int count = 0;
	            Observation obs = (Observation) in.readObject();
	            
	            int currentTime = 0;
	            LinkedList<Double> obsPerTimeX = new LinkedList<Double>();
	            LinkedList<Double> obsPerTimeY = new LinkedList<Double>();
	            while (!obs.isEOF()) {
	                System.out.println(++count + ": " + obs);
	                obs = (Observation) in.readObject();
	                if(obs.time == currentTime) {
	                	obsPerTimeX.add(obs.x);
	                	obsPerTimeY.add(obs.y);
	                }
	                else {
	                	observationByTimePerX.put(currentTime, obsPerTimeX);
	                	observationByTimePerX.put(currentTime, obsPerTimeY);
	                	obsPerTimeX.clear();
	                	obsPerTimeY.clear();
	                	currentTime++;
	                }
	            }
	            in.close();
	        } catch (IOException | ClassNotFoundException e) {
	            System.out.println("reading from " + FILENAME + "failed: " + e);
	            e.printStackTrace();
	            System.exit(1);
	        }
	        
	        
			ArrayList<Double> data = new ArrayList<Double>(Collections.nCopies(N, 1.0));   // put a 1 in each element of the data array
			ArrayList<Double> prefix = new ArrayList<Double>(Collections.nCopies(N, 0.0));
		
		
			SumHeap heap = new SumHeap(ArrayList<Integer>, 0);
			System.out.print("hw2: ");
			
			System.out.print(heap.getReduction(0));
			System.out.print(" expecting: ");
			System.out.print(N - 1);
			System.out.print("\n");
			heap.getScan(prefix);
			
		    int tally = 0;
			for (int check = 0; check < N; check++) 
			{
				Double elem = prefix.get(check);
				tally += data.get(check);
		        if (elem != tally) 
		        {
		        	System.out.print("FAILED RESULT at ");
					System.out.print(check);
					System.out.print("\n");
					return false;
		        }
		    }
			System.out.print("in ");
			System.out.print("ms");
			System.out.print("\n");

			return true;
		}
		
		public static void main(String[] args) {
			Gmems test = new Gmems();
			test.testStream();
		}
	}



