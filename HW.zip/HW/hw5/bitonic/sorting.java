package prt;

import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;
import java.util.concurrent.BrokenBarrierException;
import java.util.concurrent.CyclicBarrier;
import java.util.Scanner;




// A thread-runnable Gsorting for sorting array at a granular level

public class Gsorting implements Runnable {
    private static final int timeout = 10; 
    private CyclicBarrier[] barier;
	private CyclicBarrier jbarier;

   
    public Gsorting(double[] input, int iStart, int iEnd, int j, int k, CyclicBarrier[] granularBarrier, CyclicBarrier barrier) {
        this.input = input;
        this.j = j;
        this.iStart = iStart;
        this.iEnd = iEnd;
        this.barier = granularBarrier;
        this.jbarier = barrier;
        this.k = k;
       
    }

	
	public static String fourbits(int n) {
		String ret = /* to_string(n) + */(n > 15 ? "/1" : "/");
		for (int bit = 3; bit >= 0; bit--)
			ret += (n & (1 << bit)) > 0 ? "1" : "0";
		return ret;
	}

	
    @Override
    public void run() {

		for (int i = iStart; i < iEnd; i++) {
			int ixj = i ^ j;
			//System.out.println(""+"i : "+i+" ixj: "+ixj);
			if (ixj > i) {
				if ((i & k) == 0 && (input)[i] > (this.input)[ixj]) {
					swap(i, ixj);
					if(i < this.barier.length)
						try {
							barier[i].await();
						} catch (InterruptedException e) {
							
							e.printStackTrace();
						} catch (BrokenBarrierException e) {
						
							e.printStackTrace();
						}
				}
				if ((i & k) != 0 && (input)[i] < (this.input)[ixj]) {
					swap(i, ixj);
					if(i < this.barier.length)
						try {
							barier[i].await();
						} catch (InterruptedException e) {
							
							e.printStackTrace();
						} catch (BrokenBarrierException e) {
							
							e.printStackTrace();
						}
				}
			}
			
		}

        try
        { 
        	jbarier.await();
        }  
        catch (InterruptedException | BrokenBarrierException e)  
        { 
            e.printStackTrace(); 
        } 
    }
    
    public static boolean isSorted(double[] a, int iStart, int iEnd) {
        if (a == null)
            return false;
        double last = a[iStart];
        for (int i = 1; i < iEnd; i++) {
            if (a[i] < last) {
            }
            last = a[i];
        }
        return true;
    }

    
    private void swap(int i, int j) {
		double temp = this.input[i];
		this.input[i] = this.input[j];
		this.input[j] = temp;
	}

   

	private double[] input;
	  private int iStart;
	    private int iEnd;
    private int j;
    private int k;
  
}
 