/**
 * @file hw2.cpp - Ladner-Fischer parallel pairwise prefix sum
 * @author Kevin Lundeen
 * @see "Seattle University, CPSC5600, Winter 2020"
 *
 * Design:
 * 1. Stores interior pair-sums in a heap (interior prefix-sums are just on the exec stack).
 * 2. Calculates the sum and prefix sum recursively.
 * 3. For the top PARALLEL_LEVELS, it spawns another thread to do the right tree.
 */

#include <iostream>
#include <vector>
#include <chrono>
#include <future>

using namespace std;

const int N = 1 << 26;  // FIXME must be power of 2 for now
const int PARALLEL_LEVELS = 4;
typedef vector<int> Data;

/**
 * @class Heaper - base class for a two-part heap implementation of a complete binary tree
 * First part is given leaf elements; second part is an internally allocated array of interior elements.
 */
class Heaper {
public:
    /**
     * Constructor takes external array of leaves and internally builds interior nodes array.
     * @param data read-only input array of leaf elements
     */
    Heaper(const Data *data) : n(data->size()), data(data) {
        interior = new Data(n - 1, 0);
    }

    virtual ~Heaper() {
        delete interior;
    }

protected:
    int n; // n is size of data, n-1 is size of interior
    const Data *data;
    Data *interior;

    virtual int size() {
        return (n - 1) + n;
    }

    virtual int value(int i) {
        if (i < n - 1)
            return interior->at(i);
        else
            return data->at(i - (n - 1));
    }

    virtual int parent(int i) {
        return (i - 1) / 2;
    }

    virtual int left(int i) {
        return i * 2 + 1;
    }

    virtual int right(int i) {
        return left(i) + 1;
    }

    virtual bool isLeaf(int i) {
        return right(i) >= size();
    }
};

/**
 * @class SumHeap - Heaper superclass that has methods for calculating sums and prefix sums
 */
class SumHeap : public Heaper {
public:
    /**
     * Constructor, like the baseclass, takes the read-only data array which are the leaves of the tree.
     * Implementation note: the parallel sum is done at construction time, the prefix sum, if desired, is
     * calculated when called.
     * @param data read-only data array to use for the leaves of the tree (lifetime at least equal to this)
     */
    SumHeap(const Data *data) : Heaper(data), thread_count(1) {
        calcSum(0, 0);
    }

    /**
     * Return the sum of the subtree rooted at given node index
     * @param i  index in the heap of the sum required (the root, 0, is the default to get the grand total)
     * @return the requested sum
     */
    int sum(int i = 0) {
        return value(i);
    }

    /**
     * Fill out the n-values in the output array with the prefix sums.
     * @param output data array of size n (size of the input data array passed to the constructor)
     */
    void prefixSums(Data *output) {
        thread_count = 1;
        calcPrefix(0, 0, 0, output);
    }

    /**
     * Debugging tool for displaying the entire contents of the heap binary tree.
     */
    void dump() {
        for (int i = 0; i < size(); i++)
            cout << i << ": " << value(i) << endl;
    }

    /**
     * Return the number of threads used in the last operation (either construction or
     * prefixSums).
     * @return number of threads (including initial one)
     */
    int threadsUsed() {
        return thread_count;
    }


private:
    int thread_count;

    void calcSum(int i, int level) {
        if (!isLeaf(i)) {
            if (level < PARALLEL_LEVELS - 1) {
                auto handle = async(launch::async, &SumHeap::calcSum, this, left(i), level + 1);
                thread_count++;
                calcSum(right(i), level + 1);
                handle.wait();
            } else {
                calcSum(left(i), level + 1);
                calcSum(right(i), level + 1);
            }
            interior->at(i) = value(left(i)) + value(right(i));
        }
    }

    void calcPrefix(int i, int sumPrior, int level, Data *output) {
        if (isLeaf(i)) {
            output->at(i - (n - 1)) = sumPrior + value(i);
        } else {
            if (level < PARALLEL_LEVELS - 1) {
                auto handle = async(launch::async, &SumHeap::calcPrefix, this, left(i), sumPrior, level + 1, output);
                thread_count++;
                calcPrefix(right(i), sumPrior + sum(left(i)), level + 1, output);
                handle.wait();
            } else {
                calcPrefix(left(i), sumPrior, level + 1, output);
                calcPrefix(right(i), sumPrior + sum(left(i)), level + 1, output);
            }
        }
    }
};

/**
 * Test harness for parallel prefix sum.
 *
 * @returns 0 (success)
 */
int main() {
    Data data(N, 1);  // put a 1 in each element of the data array
    Data prefix(N, 1);

    // start timer
    auto start = chrono::steady_clock::now();

    SumHeap heap(&data);
    heap.prefixSums(&prefix);

    // stop timer
    auto end = chrono::steady_clock::now();
    auto elpased = chrono::duration<double, milli>(end - start).count();

    int check = 1;
    for (int elem: prefix)
        if (elem != check++) {
            cout << "FAILED RESULT at " << check - 1;
            break;
        }
    cout << "Computed " << N << " prefix sums in " << elpased << "ms using " << heap.threadsUsed() << " threads."
         << endl;
    return 0;
}

