


    import java.util.concurrent.SynchronousQueue;
    import java.util.concurrent.TimeUnit;
        
    public class BitonicStage implements Runnable{
        private static final int timeout = 10;  // in seconds
        
        private SynchronousQueue<double[]> input;
        private SynchronousQueue<double[]> output;
        private double[] data1;
        private double[] data2;
    
     
    
        public BitonicStage(SynchronousQueue<double[]> input, SynchronousQueue<double[]> output)
        {
            this.input = input;
            this.output = output;
        }
        
            public BitonicStage() {
        }
    
     
    
            
            
         void bitonicMerge(double a[], int i, int j) 
            { 
                if ( a[i] > a[j] ) 
                { 
                    
                    double temp = a[i]; 
                    a[i] = a[j]; 
                    a[j] = temp; 
                } 
            } 
          
           
            void bitonicSort(double a[], int low, int cnt) 
            { 
                if (cnt>1) 
                { 
                    int k = cnt/2; 
                    int high = low+k;
                    for (int i=low; i<high; i++) 
                        bitonicMerge(a,i, i+k); 
                    bitonicSort(a,low, k); 
                    bitonicSort(a,high, k); 
                } 
            }
    
     
    
        public double[] process(double[] ds, double[] ds2) {
            
            int dsLen = ds.length;
            int ds2Len = ds2.length;
           
            
            double[] result = new double[dsLen + ds2Len];
            
            
            
            int ds2Iter = ds2Len-1;
            int iter = dsLen;
            while(ds2Iter >= 0)
            {
                result[ds2Iter] = ds[ds2Iter];
                result[iter++] = ds2[ds2Iter--];
            }
            
            bitonicSort(result, 0, result.length); 
            
            return result;
        }
    
     
    //invoking thread from run() method
        @Override
        public void run() {
            while (true) {
                try {
                    data1 = input.poll(timeout * 1000, TimeUnit.MILLISECONDS);
                if(data2 == null && data1 != null)
                        data2 = input.poll(timeout * 1000, TimeUnit.MILLISECONDS);
                    if (data1 != null && data2 != null) {
                        output.offer(process(data1, data2), timeout * 1000, TimeUnit.MILLISECONDS);
                    }
                } catch (InterruptedException e) {
                    return;
                }
            }
        }
        
        
    }


    
