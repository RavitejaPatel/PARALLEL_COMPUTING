package com.rt;

import java.util.ArrayList;
import java.util.concurrent.ForkJoinPool;
import java.util.concurrent.RecursiveAction;


public abstract class Gscan {
	
	int n;
	public ArrayList<Integer> data;
	int height;
	private static final long serialVersionUID = 1L;
	int ROOT = 0;
	boolean reduced;
	final int N_THREADS = 16;
	public ArrayList<Integer> interior;
	public Gscan(final ArrayList<Integer> data2, Integer defaultValue) {
		reduced = false;
		n = data2.size();
		data = data2;
		height = (int)Math.ceil((double)Math.log(n)); 
		
		int i = 0;
		System.out.println("s: "+data.get(i - (n-1)));
		
	}

	Integer value(int i) {
		if (i < n-1)
			return (Integer) this.interior.get(i);
		else {
			System.out.println("value: "+data.get(i - (n-1)));
			return prepare(data.get(i - (n-1)));
		}
	}
	
	Integer getReduction(int i) {
		if(reduced) {
			return value(n-1);
		}
		reduced = true;
		ForkJoinPool pool = new ForkJoinPool();
		pool.invoke(new ComputeReduction(ROOT)); 
		System.out.println("value of n: "+n);
		return value(ROOT);
	}
	
	void getScan(ArrayList<Integer> output) {
		reduced = reduced || reduce(ROOT); // reduction ran to get the prefix tallies
		scan(ROOT, init(), output);
	}

	
	abstract Integer init();

	abstract Integer prepare(Integer datum);

		abstract Integer combine(Integer left, Integer right);

	int size() {
		return (n-1) + n;
	}
	int parent(int i) { 
		return (i-1)/2; 
	}
	int left(int i) { 

		return i*2 + 1;
	}
	int right(int i) { 
		return left(i) + 1;
	}
	boolean isLeaf(int i) {
		return right(i) >= size();
	}

	boolean reduce(int i) {
		
		return true;
	}

	void scan(int i, Integer tallyPrior, ArrayList<Integer> output) {
		if (isLeaf(i)) {
			output.add(i - (n-1), combine(tallyPrior, value(i)));
		} else {
			if (i < N_THREADS-2) {
				
				scan(right(i), combine(tallyPrior, value(left(i))), output);
			} else {
				scan(left(i), tallyPrior, output);
				scan(right(i), combine(tallyPrior, value(left(i))), output);
			}
		}
	}

    protected static int sThreshold = 10000;

	public class ComputeReduction extends RecursiveAction {
		/**
		 * 
		 */
		private static final long serialVersionUID = 1L;
		private int index;
		public ComputeReduction(int index) {
			this.index = index;
		}
		
		@Override
		protected void compute() {
	        if (isLeaf(index)) {
	            return;
	        }
	        if (index < N_THREADS-2) {
	        	invokeAll(new ComputeReduction(left(index)), new ComputeReduction(right(index)));
			} else {
				reduce(left(index));
				reduce(right(index));
			}
			interior.set(index, combine(value(left(index)), value(right(index))));
			System.out.println("Combined value: "+" left(index): "+left(index)+" value: "+value(left(index)) +" right side: "+value(right(index)));
		
		}
	}


}
